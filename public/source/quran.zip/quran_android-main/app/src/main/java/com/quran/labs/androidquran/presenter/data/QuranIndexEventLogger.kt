package com.quran.labs.androidquran.presenter.data

fun interface QuranIndexEventLogger {
  fun logAnalytics()
}
