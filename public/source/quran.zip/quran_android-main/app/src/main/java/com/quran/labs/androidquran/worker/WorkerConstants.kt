package com.quran.labs.androidquran.worker

object WorkerConstants {
  const val CLEANUP_PREFIX = "cleanup_"
  const val PAGE_TYPE = "pageType"
}
