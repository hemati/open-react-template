package com.quran.labs.androidquran.ui.adapter

interface DownloadedItemActionListener {
  fun handleDeleteItemAction()
  fun handleRankUpItemAction()
  fun handleRankDownItemAction()
}
