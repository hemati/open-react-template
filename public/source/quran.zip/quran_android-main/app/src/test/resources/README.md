test resources
==============

special thanks to [cwac-security](https://github.com/commonsguy/cwac-security)
for the test zip files (originally, `huge.zip` and `outside.zip`, but renamed
here).
