package mindustry.entities.comp;

import mindustry.annotations.Annotations.*;

@Component
abstract class DamageComp{
    float damage;
}
