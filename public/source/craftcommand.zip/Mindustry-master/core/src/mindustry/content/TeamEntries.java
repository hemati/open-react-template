package mindustry.content;

public class TeamEntries{

    public static void load(){
        //more will be added later - do these need references?

        //TODO
        //new TeamEntry(Team.derelict);
        //new TeamEntry(Team.sharded);
        //new TeamEntry(Team.malis);
        //new TeamEntry(Team.crux);
    }
}
